#!/bin/bash
source $(pipenv --venv)/bin/activate
python3 app.py
